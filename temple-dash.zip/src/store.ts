import { create } from "zustand";

export type GameStatus = "menu" | "playing" | "gameover" | "shop";
export type Action = "run" | "jump" | "slide";

export interface Obstacle {
  id: string;
  type: "JUMP" | "SLIDE" | "BLOCK" | "COIN";
  lane: number; // -1, 0, 1
  z: number; // Relative to chunk start
  collected?: boolean;
}

export interface Chunk {
  id: string;
  zStart: number;
  obstacles: Obstacle[];
}

export interface Inventory {
  wolfSpirit: number; // Invincibility
  eagleEye: number; // Magnet
  tengriBlessing: number; // Extra life
}

export interface ActiveEffects {
  wolfSpirit: number; // Time remaining
  eagleEye: number; // Time remaining
  hasTengriBlessing: boolean; // Active extra life
}

interface GameState {
  status: GameStatus;
  score: number;
  coins: number;
  speed: number;
  distance: number;
  currentLane: number; // -1, 0, 1
  action: Action;
  chunks: Chunk[];
  inventory: Inventory;
  activeEffects: ActiveEffects;

  startGame: () => void;
  gameOver: () => void;
  revive: () => void;
  reset: () => void;
  openShop: () => void;
  closeShop: () => void;
  buyItem: (item: keyof Inventory, cost: number) => void;
  activateSkill: (skill: keyof ActiveEffects) => void;
  updateEffects: (delta: number) => void;
  setLane: (lane: number) => void;
  setAction: (action: Action) => void;
  updateDistance: (delta: number) => void;
  addChunk: (chunk: Chunk) => void;
  removeOldChunks: (playerZ: number) => void;
  collectCoin: (chunkId: string, obstacleId: string) => void;
}

const INITIAL_SPEED = 25; // Faster initial speed
const CHUNK_LENGTH = 40;

export const useGameStore = create<GameState>((set, get) => ({
  status: "menu",
  score: 0,
  coins: 0, // Start with some coins for testing or 0
  speed: INITIAL_SPEED,
  distance: 0,
  currentLane: 0,
  action: "run",
  chunks: [],
  inventory: {
    wolfSpirit: 0,
    eagleEye: 0,
    tengriBlessing: 0,
  },
  activeEffects: {
    wolfSpirit: 0,
    eagleEye: 0,
    hasTengriBlessing: false,
  },

  startGame: () =>
    set((state) => ({
      status: "playing",
      score: 0,
      speed: INITIAL_SPEED,
      distance: 0,
      currentLane: 0,
      action: "run",
      chunks: generateInitialChunks(),
      activeEffects: {
        wolfSpirit: 0,
        eagleEye: 0,
        hasTengriBlessing: state.inventory.tengriBlessing > 0,
      },
    })),

  gameOver: () => {
    const state = get();
    if (state.activeEffects.hasTengriBlessing) {
      // Use Tengri's Blessing to revive
      set((state) => ({
        activeEffects: { ...state.activeEffects, hasTengriBlessing: false },
        inventory: {
          ...state.inventory,
          tengriBlessing: state.inventory.tengriBlessing - 1,
        },
        action: "run",
        // Give a brief invincibility upon revive
        activeEffects: {
          ...state.activeEffects,
          wolfSpirit: 3,
          hasTengriBlessing: false,
        },
      }));
    } else {
      set({ status: "gameover" });
    }
  },

  revive: () => set({ status: "playing" }), // Internal use

  reset: () => set({ status: "menu" }),

  openShop: () => set({ status: "shop" }),
  closeShop: () => set({ status: "menu" }),

  buyItem: (item, cost) =>
    set((state) => {
      if (state.coins >= cost) {
        return {
          coins: state.coins - cost,
          inventory: { ...state.inventory, [item]: state.inventory[item] + 1 },
        };
      }
      return state;
    }),

  activateSkill: (skill) =>
    set((state) => {
      if (skill === "hasTengriBlessing") return state; // Passive
      const invKey = skill as keyof Inventory;
      if (state.inventory[invKey] > 0 && state.activeEffects[skill] <= 0) {
        return {
          inventory: {
            ...state.inventory,
            [invKey]: state.inventory[invKey] - 1,
          },
          activeEffects: {
            ...state.activeEffects,
            [skill]: skill === "wolfSpirit" ? 5 : 10, // 5s invincibility, 10s magnet
          },
        };
      }
      return state;
    }),

  updateEffects: (delta) =>
    set((state) => ({
      activeEffects: {
        ...state.activeEffects,
        wolfSpirit: Math.max(0, state.activeEffects.wolfSpirit - delta),
        eagleEye: Math.max(0, state.activeEffects.eagleEye - delta),
      },
    })),

  setLane: (lane) => set({ currentLane: Math.max(-1, Math.min(1, lane)) }),

  setAction: (action) => set({ action }),

  updateDistance: (delta) => {
    const state = get();
    if (state.status !== "playing") return;

    const newDistance = state.distance + delta * state.speed;
    // Faster speed scaling
    const newSpeed = INITIAL_SPEED + Math.floor(newDistance / 300) * 3;

    set({
      distance: newDistance,
      speed: newSpeed,
      score: Math.floor(newDistance / 10),
    });
  },

  addChunk: (chunk) => set((state) => ({ chunks: [...state.chunks, chunk] })),

  removeOldChunks: (playerZ) =>
    set((state) => {
      // Keep chunks that are ahead of the player or slightly behind
      const activeChunks = state.chunks.filter(
        (c) => c.zStart + CHUNK_LENGTH > playerZ - 10,
      );

      // Generate new chunks if needed
      while (activeChunks.length < 6) {
        const lastChunk = activeChunks[activeChunks.length - 1];
        const newZStart = lastChunk ? lastChunk.zStart + CHUNK_LENGTH : playerZ;
        activeChunks.push(generateChunk(newZStart));
      }

      return { chunks: activeChunks };
    }),

  collectCoin: (chunkId, obstacleId) =>
    set((state) => {
      const newChunks = state.chunks.map((chunk) => {
        if (chunk.id === chunkId) {
          return {
            ...chunk,
            obstacles: chunk.obstacles.map((obs) =>
              obs.id === obstacleId ? { ...obs, collected: true } : obs,
            ),
          };
        }
        return chunk;
      });
      return {
        chunks: newChunks,
        coins: state.coins + 1,
        score: state.score + 50,
      };
    }),
}));

let chunkCounter = 0;
let obstacleCounter = 0;

function generateInitialChunks(): Chunk[] {
  chunkCounter = 0;
  obstacleCounter = 0;
  const chunks: Chunk[] = [];
  // First chunks are safe
  chunks.push({ id: `chunk_${chunkCounter++}`, zStart: 0, obstacles: [] });
  chunks.push({
    id: `chunk_${chunkCounter++}`,
    zStart: CHUNK_LENGTH,
    obstacles: [],
  });

  for (let i = 2; i < 6; i++) {
    chunks.push(generateChunk(i * CHUNK_LENGTH));
  }
  return chunks;
}

function generateChunk(zStart: number): Chunk {
  const obstacles: Obstacle[] = [];

  // Add 1 to 4 obstacles per chunk
  const numObstacles = Math.floor(Math.random() * 4) + 1;
  const usedZ = new Set<number>();

  for (let i = 0; i < numObstacles; i++) {
    const z = Math.floor(Math.random() * (CHUNK_LENGTH / 5)) * 5 + 5; // 5, 10, 15, 20, 25, 30, 35
    if (usedZ.has(z) || z >= CHUNK_LENGTH) continue;
    usedZ.add(z);

    const lane = Math.floor(Math.random() * 3) - 1; // -1, 0, 1
    const rand = Math.random();
    let type: Obstacle["type"] = "BLOCK";

    if (rand < 0.3) type = "JUMP";
    else if (rand < 0.6) type = "SLIDE";
    else if (rand < 0.8) type = "COIN";

    obstacles.push({
      id: `obs_${obstacleCounter++}`,
      type,
      lane,
      z,
    });

    // Sometimes add coins in a line
    if (type === "COIN") {
      for (let j = 1; j < 3; j++) {
        if (z + j * 2 < CHUNK_LENGTH && !usedZ.has(z + j * 2)) {
          obstacles.push({
            id: `obs_${obstacleCounter++}`,
            type: "COIN",
            lane,
            z: z + j * 2,
          });
        }
      }
    }
  }

  return {
    id: `chunk_${chunkCounter++}`,
    zStart,
    obstacles,
  };
}
