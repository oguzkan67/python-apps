import { useFrame } from "@react-three/fiber";
import { useRef, useState, useEffect } from "react";
import { useGameStore } from "../store";
import * as THREE from "three";

const LANE_WIDTH = 3;
const JUMP_HEIGHT = 4;
const JUMP_DURATION = 0.6; // seconds
const SLIDE_DURATION = 0.6;

export function Player() {
  const playerRef = useRef<THREE.Group>(null);
  const {
    currentLane,
    action,
    status,
    gameOver,
    chunks,
    distance,
    setAction,
    collectCoin,
    activeEffects,
    updateEffects,
  } = useGameStore();

  const [jumpTimer, setJumpTimer] = useState(0);
  const [slideTimer, setSlideTimer] = useState(0);

  const collectedCoins = useRef<Set<string>>(new Set());
  const targetX = currentLane * LANE_WIDTH;

  useFrame((state, delta) => {
    if (status !== "playing" || !playerRef.current) return;

    updateEffects(delta);

    // Smooth lane changing
    playerRef.current.position.x = THREE.MathUtils.lerp(
      playerRef.current.position.x,
      targetX,
      15 * delta,
    );

    // Handle Jump
    let currentY = 0;
    if (action === "jump") {
      const newTimer = jumpTimer + delta;
      if (newTimer >= JUMP_DURATION) {
        setAction("run");
        setJumpTimer(0);
      } else {
        setJumpTimer(newTimer);
        // Parabola: y = 4 * h * (t/d) * (1 - t/d)
        const t = newTimer / JUMP_DURATION;
        currentY = 4 * JUMP_HEIGHT * t * (1 - t);
      }
    }
    playerRef.current.position.y = currentY;

    // Handle Slide
    let scaleY = 1;
    if (action === "slide") {
      const newTimer = slideTimer + delta;
      if (newTimer >= SLIDE_DURATION) {
        setAction("run");
        setSlideTimer(0);
      } else {
        setSlideTimer(newTimer);
        scaleY = 0.4;
      }
    }
    playerRef.current.scale.y = THREE.MathUtils.lerp(
      playerRef.current.scale.y,
      scaleY,
      20 * delta,
    );

    // Collision Detection
    const playerZ = 0;
    const playerX = playerRef.current.position.x;
    const playerY = playerRef.current.position.y;

    const playerBox = new THREE.Box3().setFromObject(playerRef.current);
    // Shrink bounding box slightly to be forgiving
    playerBox.expandByScalar(-0.3);

    const isInvincible = activeEffects.wolfSpirit > 0;
    const isMagnet = activeEffects.eagleEye > 0;

    for (const chunk of chunks) {
      // Only check chunks that are near the player
      if (chunk.zStart <= distance + 15 && chunk.zStart + 40 >= distance - 10) {
        for (const obs of chunk.obstacles) {
          if (obs.collected || collectedCoins.current.has(obs.id)) continue;

          const obsWorldZ = chunk.zStart + obs.z - distance;
          const obsX = obs.lane * LANE_WIDTH;

          // Magnet effect
          if (
            isMagnet &&
            obs.type === "COIN" &&
            obsWorldZ > 0 &&
            obsWorldZ < 15
          ) {
            // Collect coins automatically if they are close
            collectedCoins.current.add(obs.id);
            collectCoin(chunk.id, obs.id);
            continue;
          }

          // Quick distance check
          if (
            Math.abs(obsWorldZ) < 3 &&
            Math.abs(obsX - playerX) < LANE_WIDTH
          ) {
            // Detailed collision
            const obsBox = new THREE.Box3();

            if (obs.type === "COIN") {
              obsBox.setFromCenterAndSize(
                new THREE.Vector3(obsX, 1, obsWorldZ),
                new THREE.Vector3(1, 1, 1),
              );
              if (playerBox.intersectsBox(obsBox)) {
                collectedCoins.current.add(obs.id);
                collectCoin(chunk.id, obs.id);
              }
            } else {
              if (isInvincible) continue; // Skip obstacle collision if invincible

              if (obs.type === "BLOCK") {
                obsBox.setFromCenterAndSize(
                  new THREE.Vector3(obsX, 5, obsWorldZ),
                  new THREE.Vector3(2, 10, 2),
                );
              } else if (obs.type === "JUMP") {
                obsBox.setFromCenterAndSize(
                  new THREE.Vector3(obsX, 0.5, obsWorldZ),
                  new THREE.Vector3(2, 1, 2),
                );
              } else if (obs.type === "SLIDE") {
                obsBox.setFromCenterAndSize(
                  new THREE.Vector3(obsX, 6, obsWorldZ),
                  new THREE.Vector3(2, 8, 2),
                );
              }

              if (playerBox.intersectsBox(obsBox)) {
                gameOver();
              }
            }
          }
        }
      }
    }
  });

  // Reset timers when action changes externally
  useEffect(() => {
    if (action === "jump" && jumpTimer === 0) setJumpTimer(0.01);
    if (action === "slide" && slideTimer === 0) setSlideTimer(0.01);
  }, [action]);

  const isInvincible = activeEffects.wolfSpirit > 0;

  return (
    <group ref={playerRef} position={[0, 0, 0]}>
      {/* Wolf Aura (Invincibility) */}
      {isInvincible && (
        <mesh position={[0, 1, 0]}>
          <sphereGeometry args={[1.5, 16, 16]} />
          <meshBasicMaterial
            color="#60a5fa"
            transparent
            opacity={0.4}
            wireframe
          />
        </mesh>
      )}

      {/* Character Body - Turkic Warrior Theme */}
      <mesh position={[0, 1, 0]} castShadow>
        <boxGeometry args={[1, 2, 1]} />
        <meshStandardMaterial color="#b45309" roughness={0.8} />{" "}
        {/* Leather armor */}
      </mesh>
      {/* Head */}
      <mesh position={[0, 2.5, 0]} castShadow>
        <boxGeometry args={[0.8, 0.8, 0.8]} />
        <meshStandardMaterial color="#fca5a5" roughness={0.5} />
      </mesh>
      {/* Wolf Pelt / Cape */}
      <mesh position={[0, 1.2, -0.6]} castShadow>
        <boxGeometry args={[1.2, 1.8, 0.2]} />
        <meshStandardMaterial color="#52525b" roughness={0.9} />{" "}
        {/* Gray wolf pelt */}
      </mesh>
      {/* Bow on back */}
      <mesh position={[0, 1.5, -0.8]} rotation={[0, 0, Math.PI / 4]} castShadow>
        <cylinderGeometry args={[0.05, 0.05, 2]} />
        <meshStandardMaterial color="#78350f" />
      </mesh>
    </group>
  );
}
