import { useDrag } from "@use-gesture/react";
import { useGameStore } from "../store";
import { useEffect } from "react";

export function Controls({ children }: { children: React.ReactNode }) {
  const { currentLane, setLane, action, setAction, status } = useGameStore();

  const bind = useDrag(
    ({ swipe: [swipeX, swipeY] }) => {
      if (status !== "playing") return;

      if (swipeX === -1) {
        setLane(currentLane - 1);
      } else if (swipeX === 1) {
        setLane(currentLane + 1);
      }

      if (swipeY === -1) {
        // Swipe up -> jump
        if (action === "run") setAction("jump");
      } else if (swipeY === 1) {
        // Swipe down -> slide
        if (action === "run") setAction("slide");
      }
    },
    { swipe: { distance: 30 } },
  );

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (status !== "playing") return;

      switch (e.key) {
        case "ArrowLeft":
        case "a":
          setLane(currentLane - 1);
          break;
        case "ArrowRight":
        case "d":
          setLane(currentLane + 1);
          break;
        case "ArrowUp":
        case "w":
          if (action === "run") setAction("jump");
          break;
        case "ArrowDown":
        case "s":
          if (action === "run") setAction("slide");
          break;
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [currentLane, action, status, setLane, setAction]);

  return (
    <div {...bind()} className="w-full h-full absolute inset-0 touch-none">
      {children}
    </div>
  );
}
