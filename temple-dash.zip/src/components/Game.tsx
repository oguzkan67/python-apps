import { Canvas, useFrame } from "@react-three/fiber";
import { Player } from "./Player";
import { World } from "./World";
import { Sky } from "@react-three/drei";
import { useGameStore } from "../store";
import * as THREE from "three";

function CameraSetup() {
  const { currentLane } = useGameStore();

  useFrame(({ camera }, delta) => {
    const targetX = currentLane * 3 * 0.5; // Follow halfway
    camera.position.x = THREE.MathUtils.lerp(
      camera.position.x,
      targetX,
      5 * delta,
    );
    camera.lookAt(camera.position.x, 0, 10);
  });

  return null;
}

export function Game() {
  return (
    <div className="w-full h-full absolute inset-0">
      <Canvas camera={{ position: [0, 6, -8], fov: 60 }} shadows>
        <CameraSetup />
        <color attach="background" args={["#38bdf8"]} />{" "}
        {/* Kök Tengri - Eternal Blue Sky */}
        <Sky
          sunPosition={[100, 20, 100]}
          turbidity={0.1}
          rayleigh={0.1}
          mieCoefficient={0.005}
          mieDirectionalG={0.8}
        />
        <ambientLight intensity={0.6} />
        <directionalLight
          castShadow
          position={[20, 30, -10]}
          intensity={1.5}
          shadow-mapSize={[2048, 2048]}
          shadow-camera-left={-20}
          shadow-camera-right={20}
          shadow-camera-top={20}
          shadow-camera-bottom={-20}
          shadow-camera-near={0.1}
          shadow-camera-far={100}
        />
        <Player />
        <World />
        <fog attach="fog" args={["#38bdf8", 30, 100]} />
      </Canvas>
    </div>
  );
}
