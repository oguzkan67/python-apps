import { useFrame } from "@react-three/fiber";
import { useRef } from "react";
import { useGameStore } from "../store";
import * as THREE from "three";

const LANE_WIDTH = 3;
const CHUNK_LENGTH = 40;

function Coin({ position }: { position: [number, number, number] }) {
  const ref = useRef<THREE.Mesh>(null);
  useFrame((_, delta) => {
    if (ref.current) {
      ref.current.rotation.y += delta * 3;
    }
  });
  return (
    <mesh ref={ref} position={position} castShadow>
      <cylinderGeometry args={[0.5, 0.5, 0.1, 16]} />
      <meshStandardMaterial color="#fbbf24" metalness={0.8} roughness={0.2} />
      {/* Small inner hole to look like ancient coin */}
      <mesh position={[0, 0, 0]}>
        <cylinderGeometry args={[0.15, 0.15, 0.12, 16]} />
        <meshBasicMaterial color="#000000" />
      </mesh>
    </mesh>
  );
}

export function World() {
  const { chunks, distance, updateDistance, removeOldChunks, status } =
    useGameStore();
  const groupRef = useRef<THREE.Group>(null);

  useFrame((_, delta) => {
    if (status === "playing") {
      updateDistance(delta);
      removeOldChunks(distance);
    }
  });

  return (
    <group ref={groupRef} position={[0, 0, -distance]}>
      {chunks.map((chunk) => (
        <group key={chunk.id} position={[0, 0, chunk.zStart]}>
          {/* Ground - Steppe Grass */}
          <mesh position={[0, -0.5, CHUNK_LENGTH / 2]} receiveShadow>
            <boxGeometry args={[LANE_WIDTH * 3, 1, CHUNK_LENGTH]} />
            <meshStandardMaterial color="#84cc16" roughness={1} />
          </mesh>

          {/* Walls - Ancient Stones / Mountains */}
          <mesh
            position={[-LANE_WIDTH * 1.5 - 0.5, 1, CHUNK_LENGTH / 2]}
            receiveShadow
          >
            <boxGeometry args={[1, 4, CHUNK_LENGTH]} />
            <meshStandardMaterial color="#57534e" roughness={0.9} />
          </mesh>
          <mesh
            position={[LANE_WIDTH * 1.5 + 0.5, 1, CHUNK_LENGTH / 2]}
            receiveShadow
          >
            <boxGeometry args={[1, 4, CHUNK_LENGTH]} />
            <meshStandardMaterial color="#57534e" roughness={0.9} />
          </mesh>

          {/* Lane dividers - Faded dirt paths */}
          <mesh
            position={[-LANE_WIDTH / 2, 0.01, CHUNK_LENGTH / 2]}
            rotation={[-Math.PI / 2, 0, 0]}
            receiveShadow
          >
            <planeGeometry args={[0.2, CHUNK_LENGTH]} />
            <meshBasicMaterial color="#a16207" opacity={0.4} transparent />
          </mesh>
          <mesh
            position={[LANE_WIDTH / 2, 0.01, CHUNK_LENGTH / 2]}
            rotation={[-Math.PI / 2, 0, 0]}
            receiveShadow
          >
            <planeGeometry args={[0.2, CHUNK_LENGTH]} />
            <meshBasicMaterial color="#a16207" opacity={0.4} transparent />
          </mesh>

          {/* Obstacles */}
          {chunk.obstacles.map((obs) => {
            if (obs.collected) return null;

            const x = obs.lane * LANE_WIDTH;
            const z = obs.z;

            if (obs.type === "COIN") {
              return <Coin key={obs.id} position={[x, 1, z]} />;
            }

            if (obs.type === "BLOCK") {
              return (
                <group key={obs.id} position={[x, 0, z]}>
                  {/* Ancient Totem / Balbal */}
                  <mesh position={[0, 2, 0]} castShadow>
                    <boxGeometry args={[1.5, 4, 1.5]} />
                    <meshStandardMaterial color="#78716c" roughness={0.9} />
                  </mesh>
                  {/* Face carving suggestion */}
                  <mesh position={[0, 3, 0.76]}>
                    <boxGeometry args={[0.8, 0.8, 0.1]} />
                    <meshStandardMaterial color="#44403c" />
                  </mesh>
                </group>
              );
            }

            if (obs.type === "JUMP") {
              return (
                <group key={obs.id} position={[x, 0, z]}>
                  {/* Fallen Log */}
                  <mesh
                    position={[0, 0.5, 0]}
                    rotation={[0, 0, Math.PI / 2]}
                    castShadow
                  >
                    <cylinderGeometry args={[0.5, 0.5, 2.5, 8]} />
                    <meshStandardMaterial color="#451a03" roughness={1} />
                  </mesh>
                </group>
              );
            }

            if (obs.type === "SLIDE") {
              return (
                <group key={obs.id} position={[x, 0, z]}>
                  {/* Wooden Archway */}
                  <mesh position={[-1, 1.5, 0]} castShadow>
                    <cylinderGeometry args={[0.2, 0.2, 3]} />
                    <meshStandardMaterial color="#451a03" roughness={1} />
                  </mesh>
                  <mesh position={[1, 1.5, 0]} castShadow>
                    <cylinderGeometry args={[0.2, 0.2, 3]} />
                    <meshStandardMaterial color="#451a03" roughness={1} />
                  </mesh>
                  <mesh
                    position={[0, 2.9, 0]}
                    rotation={[0, 0, Math.PI / 2]}
                    castShadow
                  >
                    <cylinderGeometry args={[0.2, 0.2, 2.4]} />
                    <meshStandardMaterial color="#451a03" roughness={1} />
                  </mesh>
                  {/* Hanging charms */}
                  <mesh position={[-0.5, 2.5, 0]}>
                    <boxGeometry args={[0.1, 0.6, 0.1]} />
                    <meshStandardMaterial color="#ef4444" />
                  </mesh>
                  <mesh position={[0.5, 2.5, 0]}>
                    <boxGeometry args={[0.1, 0.6, 0.1]} />
                    <meshStandardMaterial color="#3b82f6" />
                  </mesh>
                </group>
              );
            }

            return null;
          })}
        </group>
      ))}
    </group>
  );
}
