import { useGameStore } from "../store";
import { Shield, Magnet, Heart } from "lucide-react";

export function UI() {
  const {
    status,
    score,
    coins,
    startGame,
    openShop,
    closeShop,
    buyItem,
    inventory,
    activeEffects,
    activateSkill,
  } = useGameStore();

  if (status === "shop") {
    return (
      <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/90 text-white z-20 backdrop-blur-md p-4">
        <h1 className="text-5xl font-black mb-2 text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-500">
          TENGRI'S BAZAAR
        </h1>
        <div className="text-yellow-400 font-mono text-2xl mb-8">
          Coins: {coins}
        </div>

        <div className="flex flex-col gap-4 w-full max-w-md">
          <ShopItem
            name="Wolf Spirit"
            desc="Invincibility for 5 seconds"
            cost={100}
            owned={inventory.wolfSpirit}
            icon={<Shield className="w-6 h-6 text-blue-400" />}
            onBuy={() => buyItem("wolfSpirit", 100)}
            canBuy={coins >= 100}
          />
          <ShopItem
            name="Eagle Eye"
            desc="Coin magnet for 10 seconds"
            cost={150}
            owned={inventory.eagleEye}
            icon={<Magnet className="w-6 h-6 text-purple-400" />}
            onBuy={() => buyItem("eagleEye", 150)}
            canBuy={coins >= 150}
          />
          <ShopItem
            name="Tengri's Blessing"
            desc="Passive: Revive once upon death"
            cost={300}
            owned={inventory.tengriBlessing}
            icon={<Heart className="w-6 h-6 text-red-400" />}
            onBuy={() => buyItem("tengriBlessing", 300)}
            canBuy={coins >= 300}
          />
        </div>

        <button
          onClick={closeShop}
          className="mt-8 px-8 py-3 bg-white/10 hover:bg-white/20 rounded-full text-xl font-bold transition-all border border-white/20"
        >
          BACK TO MENU
        </button>
      </div>
    );
  }

  if (status === "menu") {
    return (
      <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 text-white z-10 backdrop-blur-sm">
        <h1 className="text-6xl md:text-8xl font-black mb-4 italic tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-600 drop-shadow-[0_0_20px_rgba(56,189,248,0.5)]">
          KÖK TENGRI
        </h1>
        <h2 className="text-2xl md:text-4xl font-bold mb-8 tracking-widest text-orange-400">
          BOZKURT RUN
        </h2>
        <p className="mb-12 text-lg text-gray-300 font-medium text-center px-4 max-w-md">
          Swipe or use Arrow Keys to move, jump, and slide. Collect ancient
          coins and survive the steppe.
        </p>

        <div className="flex flex-col gap-4">
          <button
            onClick={startGame}
            className="px-12 py-4 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 rounded-full text-2xl font-black tracking-widest transition-all hover:scale-105 active:scale-95 shadow-[0_0_40px_rgba(56,189,248,0.5)] border-2 border-cyan-300/50"
          >
            RIDE
          </button>
          <button
            onClick={openShop}
            className="px-12 py-4 bg-gradient-to-r from-orange-600 to-red-700 hover:from-orange-500 hover:to-red-600 rounded-full text-xl font-bold tracking-widest transition-all hover:scale-105 active:scale-95 shadow-[0_0_20px_rgba(249,115,22,0.3)] border-2 border-orange-400/50"
          >
            BAZAAR
          </button>
        </div>
      </div>
    );
  }

  if (status === "gameover") {
    return (
      <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/80 text-white z-10 backdrop-blur-md">
        <h1 className="text-7xl font-black mb-6 text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-rose-600 drop-shadow-lg">
          FALLEN
        </h1>
        <div className="flex gap-8 mb-12">
          <div className="bg-white/10 rounded-2xl p-6 backdrop-blur-sm border border-white/20 text-center min-w-[150px]">
            <div className="text-gray-400 text-sm font-bold uppercase tracking-wider mb-2">
              Distance
            </div>
            <div className="text-4xl font-mono font-black text-white">
              {score}
            </div>
          </div>
          <div className="bg-white/10 rounded-2xl p-6 backdrop-blur-sm border border-white/20 text-center min-w-[150px]">
            <div className="text-gray-400 text-sm font-bold uppercase tracking-wider mb-2">
              Coins
            </div>
            <div className="text-4xl font-mono font-black text-yellow-400">
              {coins}
            </div>
          </div>
        </div>
        <div className="flex flex-col gap-4">
          <button
            onClick={startGame}
            className="px-10 py-5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 rounded-full text-2xl font-black tracking-widest transition-all hover:scale-105 active:scale-95 shadow-[0_0_40px_rgba(56,189,248,0.5)] border-2 border-cyan-300/50"
          >
            RIDE AGAIN
          </button>
          <button
            onClick={openShop}
            className="px-10 py-4 bg-white/10 hover:bg-white/20 rounded-full text-xl font-bold transition-all border border-white/20 text-center"
          >
            VISIT BAZAAR
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="absolute inset-0 pointer-events-none z-10 flex flex-col justify-between p-6">
      {/* Top Bar */}
      <div className="flex justify-between items-start">
        <div className="bg-black/40 rounded-2xl p-4 backdrop-blur-md border border-white/10 shadow-xl">
          <div className="text-gray-300 text-xs font-bold uppercase tracking-widest mb-1">
            Distance
          </div>
          <div className="text-3xl font-mono font-black text-white leading-none">
            {score}
          </div>
        </div>
        <div className="bg-black/40 rounded-2xl p-4 backdrop-blur-md border border-white/10 shadow-xl text-right">
          <div className="text-gray-300 text-xs font-bold uppercase tracking-widest mb-1">
            Coins
          </div>
          <div className="text-3xl font-mono font-black text-yellow-400 leading-none">
            {coins}
          </div>
        </div>
      </div>

      {/* Skills Bar */}
      <div className="flex justify-center gap-4 pointer-events-auto">
        <SkillButton
          name="Wolf Spirit"
          icon={<Shield className="w-6 h-6" />}
          count={inventory.wolfSpirit}
          active={activeEffects.wolfSpirit > 0}
          onClick={() => activateSkill("wolfSpirit")}
          color="bg-blue-500"
        />
        <SkillButton
          name="Eagle Eye"
          icon={<Magnet className="w-6 h-6" />}
          count={inventory.eagleEye}
          active={activeEffects.eagleEye > 0}
          onClick={() => activateSkill("eagleEye")}
          color="bg-purple-500"
        />
        <div className="relative">
          <div
            className={`w-14 h-14 rounded-full flex items-center justify-center border-2 ${activeEffects.hasTengriBlessing ? "border-red-400 bg-red-500/20 text-red-400" : "border-gray-600 bg-gray-800/50 text-gray-600"}`}
          >
            <Heart className="w-6 h-6" />
          </div>
          {inventory.tengriBlessing > 0 && (
            <div className="absolute -top-2 -right-2 bg-black text-white text-xs font-bold w-6 h-6 rounded-full flex items-center justify-center border border-white/20">
              {inventory.tengriBlessing}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function ShopItem({ name, desc, cost, owned, icon, onBuy, canBuy }: any) {
  return (
    <div className="bg-white/10 rounded-xl p-4 border border-white/10 flex items-center justify-between">
      <div className="flex items-center gap-4">
        <div className="p-3 bg-black/30 rounded-lg">{icon}</div>
        <div>
          <div className="font-bold text-lg">{name}</div>
          <div className="text-xs text-gray-400">{desc}</div>
          <div className="text-sm text-gray-300 mt-1">Owned: {owned}</div>
        </div>
      </div>
      <button
        onClick={onBuy}
        disabled={!canBuy}
        className={`px-4 py-2 rounded-lg font-bold transition-all ${
          canBuy
            ? "bg-yellow-500 hover:bg-yellow-400 text-black"
            : "bg-gray-700 text-gray-500 cursor-not-allowed"
        }`}
      >
        {cost} C
      </button>
    </div>
  );
}

function SkillButton({ icon, count, active, onClick, color }: any) {
  return (
    <button
      onClick={onClick}
      disabled={count === 0 && !active}
      className={`relative w-14 h-14 rounded-full flex items-center justify-center transition-all border-2 ${
        active
          ? `${color} border-white shadow-[0_0_15px_rgba(255,255,255,0.5)] animate-pulse text-white`
          : count > 0
            ? "bg-black/60 border-white/50 hover:border-white text-white"
            : "bg-black/40 border-gray-700 text-gray-600 cursor-not-allowed"
      }`}
    >
      {icon}
      {count > 0 && !active && (
        <div className="absolute -top-2 -right-2 bg-white text-black text-xs font-bold w-6 h-6 rounded-full flex items-center justify-center border border-black">
          {count}
        </div>
      )}
    </button>
  );
}
